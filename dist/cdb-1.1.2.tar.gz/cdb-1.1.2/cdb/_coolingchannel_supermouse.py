"CoolingChannelSuperMouse module."

from xml.sax import parseString

from cdb._coolingchannel import CoolingChannel
from cdb._exceptions import CdbPermanentError

__all__ = ["CoolingChannelSuperMouse"]

class CoolingChannelSuperMouse(CoolingChannel):
    
    """
The CoolingChannelSuperMouse class is used to set and retrieve cooling channel
settings.

Cooling channel data is stored using the set_coolingchannel method. All
available data can be retrieved using get_all_coolingchannels. A number of
methods are available to retrieve subsets of the data,
get_coolingchannel_for_run and get_coolingchannel_for_date.

In addition there is the concept of tagged data. It is possible to tag a set of
parameters using set_coolingchannel_tag. Tagged parameters can then be retrieved
using get_coolingchannel_for_tag. The use of set_coolingchannel_tag with an
existing tag name will replace the existing parameters, although the original
parameters will still be stored in the database.

    """
    
    def __init__(self, url=""):
        """
Construct a CoolingChannelSuperMouse.

@param url: the url of the server in the form 'http://host.domain:port'

@exception CdbPermanentError: Unable to contact CDB server or invalid URL

        """

        super(CoolingChannelSuperMouse, self).__init__(url,
            "/cdb/coolingChannelSuperMouse?wsdl")

    def __str__(self):
        _help_super = "\n\tset_coolingchannel(list(dict) data) \
        \n\tset_coolingchannel_tag(str tag, list(dict) data)"
        return "CoolingChannelSuperMouse" + self._help + _help_super


    def set_coolingchannel(self, data):
        """
Add the parameters associated with a cooling channel.

@param data a list of dictionaries with the following keys/values:<pre>
    key - name, value - a string representing the magnet name
    key - mode, value - a string representing the magnet mode
    key - polarity, value - a string representing the magnet polarity
    key - coils, value - a list of dictionaries containing coil data
    coils dictionary:
        key - name, value - a string representing the magnet name
        key - calibration, value - a float
        key - ilim, value - a float
        key - iset, value - a float
        key - rate, value - a float
        key - stability, value - a float
        key - vlim, value - a float</pre>

@return a string containing a status message

@exception CdbTemporaryError: The problem maybe transient and retrying the
request MAY succeed
@exception CdbPermanentError: Maybe due to to bad data being passed in or an
unexpected internal error

        """
        try:
            xml = ("<coolingchannel>")                    
                      
            for magnet in data:
                if (str(magnet['polarity']) != "-1" 
                    and str(magnet['polarity']) != "0" 
                    and str(magnet['polarity']) != "1" 
                    and str(magnet['polarity']) != "+1"):
                    raise CdbPermanentError("Polarity for " + magnet['name'] 
                                            + " is " + str(magnet['polarity']) 
                                            + ", it must be -1, 0 or +1")
                xml = xml + "<magnet name='" + str(magnet['name']) + "' "
                xml = xml + "mode='" + str(magnet['mode']) + "' "
                xml = xml + "polarity='" + str(magnet['polarity']) + "'>"
                
                coils = magnet['coils']
                for coil in coils:
                    xml = xml + "<coil name='" + str(coil['name']) + "' "
                    xml = (xml + "calibration='" 
                              + str(coil['calibration']) + "' ")
                    xml = xml + "ilim='" + str(coil['ilim']) + "' "
                    xml = xml + "iset='" + str(coil['iset']) + "' "
                    xml = xml + "rate='" + str(coil['rate']) + "' "
                    xml = (xml + "stability='" + str(coil['stability']) 
                              + "' ")
                    xml = xml + "vlim='" + str(coil['vlim']) + "'/>"
                
                xml = xml + "</magnet>"
            xml = xml + "</coolingchannel>"
        except KeyError, exception:
            raise CdbPermanentError("Missing value for " + str(exception))
        return_xml = str(self._server.setCoolingchannel(str(xml)))
        parseString(return_xml, self._status_handler)
        return self._status_handler.get_message()



    def set_coolingchannel_tag(self, tag, data):
        """
Add a tagged set of cooling channel parameters.

@param tag a string containing the name of the tag 
@param data a list of dictionaries with the following keys/values:<pre>
    key - name, value - a string representing the magnet name
    key - mode, value - a string representing the magnet mode
    key - polarity, value - a string representing the magnet polarity
    key - coils, value - a list of dictionaries containing coil data
    coils dictionary:
        key - name, value - a string representing the magnet name
        key - calibration, value - a float
        key - ilim, value - a float
        key - iset, value - a float
        key - rate, value - a float
        key - stability, value - a float
        key - vlim, value - a float</pre>

@return a string containing a status message

@exception CdbTemporaryError: The problem maybe transient and retrying the
request MAY succeed
@exception CdbPermanentError: Maybe due to to bad data being passed in or an
unexpected internal error

        """
        try:
            xml = ("<tag name='" + str(tag) + "'>")
                      
            for magnet in data:
                if (str(magnet['polarity']) != "-1" 
                    and str(magnet['polarity']) != "0" 
                    and str(magnet['polarity']) != "1" 
                    and str(magnet['polarity']) != "+1"):
                    raise CdbPermanentError("Polarity for " + magnet['name'] 
                                            + " is " + str(magnet['polarity']) 
                                            + ", it must be -1, 0 or +1")
                xml = xml + "<magnet name='" + str(magnet['name']) + "' "
                xml = xml + "mode='" + str(magnet['mode']) + "' "
                xml = xml + "polarity='" + str(magnet['polarity']) + "'>"
                
                coils = magnet['coils']
                for coil in coils:
                    xml = xml + "<coil name='" + str(coil['name']) + "' "
                    xml = (xml + "calibration='" 
                              + str(coil['calibration']) + "' ")
                    xml = xml + "ilim='" + str(coil['ilim']) + "' "
                    xml = xml + "iset='" + str(coil['iset']) + "' "
                    xml = xml + "rate='" + str(coil['rate']) + "' "
                    xml = (xml + "stability='" + str(coil['stability']) 
                              + "' ")
                    xml = xml + "vlim='" + str(coil['vlim']) + "'/>"
                
                xml = xml + "</magnet>"
            xml = xml + "</tag>"
        except KeyError, exception:
            raise CdbPermanentError("Missing value for " + str(exception))
        return_xml = str(self._server.setCoolingchannelTag(str(xml)))
        parseString(return_xml, self._status_handler)
        return self._status_handler.get_message()

